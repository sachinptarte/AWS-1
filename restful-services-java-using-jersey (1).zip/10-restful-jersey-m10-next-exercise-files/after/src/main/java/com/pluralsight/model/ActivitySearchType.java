package com.pluralsight.model;

public enum ActivitySearchType {

	SEARCH_BY_DURATION_RANGE, SEARCH_BY_DESCRIPTION;
	
}
